#include<stdio.h>
#include<stdlib.h>
int main(){
	int a=10;
	printf("Hello");
	return 0;
}
